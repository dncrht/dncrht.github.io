require 'rubygems'
require 'benchmark'
require 'httparty'

def create_session
  HTTParty.get('http://localhost:3000/users?option=payload' << ('_' * 400))
end

def reuse_session(response)
  HTTParty.get('http://localhost:3000/users', :headers => {'Cookie' => response.headers['Set-Cookie']})
end

@response = create_session

Benchmark.bm do |benchmark|
 benchmark.report do
   2000.times { reuse_session(@response) }
 end
 benchmark.report do
   1000.times { response = create_session; reuse_session(response) }
 end
end

