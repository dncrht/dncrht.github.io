# Be sure to restart your server when you modify this file.

Four::Application.config.session_store :cookie_store, :key => '_four_session'

