# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Four::Application.config.secret_key_base = '7f0d14e8e7815cbfd1e292b46bece3fe73b625abcc454243535aa136da59968e55b0eea180c269d23a33ecdcd6ed3019a94b48110fa0d86a59fc1c1b0a9483a9'
