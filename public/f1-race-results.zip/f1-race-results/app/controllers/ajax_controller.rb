class AjaxController < ApplicationController

  def index
    @standings = Standing.after_lap(0)
  end

  def results
    standings = Standing.after_lap(66)

  	render partial: '/layouts/standings_table', locals: {standings: standings}
  end

end
