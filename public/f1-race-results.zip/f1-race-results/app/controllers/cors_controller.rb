class CorsController < ApplicationController

  #http_basic_authenticate_with name: 'user', password: 'password'

  def index
    @standings = Standing.after_lap(0)
  end

  def results
    standings = Standing.after_lap(66)

    # Uncomment if you don't use Rack::Cors
    #headers['Access-Control-Allow-Origin']= 'http://localhost:3000'

  	render partial: '/layouts/standings_table', locals: {standings: standings}
  end

end
