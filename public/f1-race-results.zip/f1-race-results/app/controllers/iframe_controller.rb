class IframeController < ApplicationController

  def index
    @standings = Standing.after_lap(0)
  end

  def results
    @standings = Standing.after_lap(66)

  	render layout: nil
  end

end
