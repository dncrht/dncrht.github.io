class Standing

	def self.after_lap(lap)

		case lap

		when 0

			{
				1 => {driver: 'Nico Rosberg', team: 'Mercedes'},
				2 => {driver: 'Lewis Hamilton', team: 'Mercedes'},
				3 => {driver: 'Daniel Ricciardo', team: 'Red Bull Racing-Renault'},
			}

		when 66

			{
				1 => {driver: 'Lewis Hamilton', team: 'Mercedes'},
				2 => {driver: 'Nico Rosberg', team: 'Mercedes'},
				3 => {driver: 'Sergio Pérez', team: 'Force India-Mercedes'},
			}

		end
	end

end
