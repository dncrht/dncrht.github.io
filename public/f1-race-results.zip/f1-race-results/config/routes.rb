F1RaceResults::Application.routes.draw do

  # Background request with an iframe
  get 'iframe' => 'iframe#index'
  get 'iframe/results' => 'iframe#results'

  # Background request with AJAX
  get 'ajax' => 'ajax#index'
  get 'ajax/results' => 'ajax#results'

  # Background request with JSONP
  get 'jsonp' => 'jsonp#index'
  get 'jsonp/results' => 'jsonp#results'

  # Background request with CORS
  get 'cors' => 'cors#index'
  match 'cors/results' => 'cors#results', via: [:get, :post]

end
