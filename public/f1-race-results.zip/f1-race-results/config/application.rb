require File.expand_path('../boot', __FILE__)

require "action_controller/railtie"
require "action_mailer/railtie"
require "sprockets/railtie"

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(:default, Rails.env)

module F1RaceResults
  class Application < Rails::Application

    # CORS configuration
    # Remove completely this for testing purposes
    #
    config.middleware.use Rack::Cors do
      allow do
        origins 'localhost:3000'
        resource '*', headers: :any, methods: %i(get post)
      end
    end

  end
end
